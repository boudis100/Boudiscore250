# Napínáky řemenů

Obsahuje dva typy napínáků: pružinový a šroubový.