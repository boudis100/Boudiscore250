# Montážní návod – Napínáky řemenů

Tento dokument popisuje montáž napínáků pro CoreXY tiskárnu BoudiCore250.